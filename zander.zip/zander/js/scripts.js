// Empty JS for your own code to be here
$('.play').click(function() {
  video = '<iframe width="100%" height="281" frameborder="0" src="' + $('img').attr('data-video') + '"></iframe>';
  $('.video').replaceWith(video);
});